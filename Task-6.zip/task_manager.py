import os
from datetime import datetime

TASKS_FILE = "tasks.txt"


class Task:
    def __init__(self, task_id, title, description, status, due_date):
        self.id = task_id
        self.title = title
        self.description = description
        self.status = status
        self.due_date = due_date

    def __str__(self):
        return f"{self.id},{self.title},{self.description},{self.status},{self.due_date}"

    @staticmethod
    def from_string(task_str):
        parts = task_str.strip().split(",")
        return Task(int(parts[0]), parts[1], parts[2], parts[3], parts[4])


def load_tasks():
    if not os.path.exists(TASKS_FILE):
        return []
    with open(TASKS_FILE, "r") as file:
        return [Task.from_string(line) for line in file.readlines()]


def save_tasks(tasks):
    with open(TASKS_FILE, "w") as file:
        for task in tasks:
            file.write(str(task) + "\n")


def add_task():
    tasks = load_tasks()
    task_id = 1 if not tasks else tasks[-1].id + 1
    title = input("Enter task title: ")
    description = input("Enter task description: ")
    due_date = input("Enter due date (YYYY-MM-DD): ")
    task = Task(task_id, title, description, "Pending", due_date)
    tasks.append(task)
    save_tasks(tasks)
    print("✅ Task added successfully!\n")


def view_tasks():
    tasks = load_tasks()
    if not tasks:
        print("No tasks found.\n")
        return
    print("\n📋 All Tasks:")
    print("{:<5} {:<15} {:<25} {:<12} {:<12}".format("ID", "Title", "Description", "Status", "Due Date"))
    print("-" * 75)
    for t in tasks:
        print("{:<5} {:<15} {:<25} {:<12} {:<12}".format(t.id, t.title, t.description, t.status, t.due_date))
    print()


def update_task():
    tasks = load_tasks()
    task_id = int(input("Enter task ID to update: "))
    for task in tasks:
        if task.id == task_id:
            print("1. Update Title")
            print("2. Update Description")
            print("3. Mark as Completed")
            choice = input("Choose an option: ")
            if choice == "1":
                task.title = input("Enter new title: ")
            elif choice == "2":
                task.description = input("Enter new description: ")
            elif choice == "3":
                task.status = "Completed"
            save_tasks(tasks)
            print("✅ Task updated successfully!\n")
            return
    print("❌ Task not found.\n")


def delete_task():
    tasks = load_tasks()
    task_id = int(input("Enter task ID to delete: "))
    updated_tasks = [task for task in tasks if task.id != task_id]
    if len(updated_tasks) == len(tasks):
        print("❌ Task not found.\n")
    else:
        save_tasks(updated_tasks)
        print("🗑️ Task deleted successfully!\n")


def main():
    while True:
        print("=== Task Manager ===")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Update Task")
        print("4. Delete Task")
        print("5. Exit")
        choice = input("Enter your choice (1-5): ")

        if choice == "1":
            add_task()
        elif choice == "2":
            view_tasks()
        elif choice == "3":
            update_task()
        elif choice == "4":
            delete_task()
        elif choice == "5":
            print("👋 Exiting Task Manager. Goodbye!")
            break
        else:
            print("❌ Invalid choice. Please try again.\n")


if __name__ == "__main__":
    main()
